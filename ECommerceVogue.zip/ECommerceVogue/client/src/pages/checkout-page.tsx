import { useState, useEffect } from 'react';
import { useStripe, useElements, PaymentElement, Elements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { motion } from 'framer-motion';
import { useCart } from '@/hooks/use-cart';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { apiRequest } from '@/lib/queryClient';
import { Link, useLocation } from 'wouter';
import { Loader2, CheckCircle, AlertCircle } from 'lucide-react';

// Use the test publishable key for development
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY || 'pk_test_TYooMQauvdEDq54NiTphI7jx');

const CheckoutForm = () => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [checkoutError, setCheckoutError] = useState<string | null>(null);
  const [checkoutSuccess, setCheckoutSuccess] = useState(false);
  const { clearCart, totalPrice } = useCart();
  const { toast } = useToast();
  const stripe = useStripe();
  const elements = useElements();
  const [, navigate] = useLocation();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      // Stripe.js hasn't loaded yet
      return;
    }

    setIsProcessing(true);
    setCheckoutError(null);

    try {
      const { error } = await stripe.confirmPayment({
        elements,
        confirmParams: {
          // Return URL where the customer should be redirected after payment
          return_url: `${window.location.origin}/checkout/success`,
        },
        redirect: 'if_required',
      });

      if (error) {
        setCheckoutError(error.message || 'An error occurred during payment.');
        toast({
          title: 'Payment failed',
          description: error.message || 'An error occurred during payment.',
          variant: 'destructive',
        });
      } else {
        // Payment succeeded
        setCheckoutSuccess(true);
        toast({
          title: 'Payment successful',
          description: 'Thank you for your purchase!',
        });
        clearCart();
        setTimeout(() => {
          navigate('/client/purchases');
        }, 2000);
      }
    } catch (err) {
      console.error('Payment error:', err);
      setCheckoutError('An unexpected error occurred.');
      toast({
        title: 'Payment error',
        description: 'An unexpected error occurred during processing.',
        variant: 'destructive',
      });
    } finally {
      setIsProcessing(false);
    }
  };

  if (checkoutSuccess) {
    return (
      <div className="text-center py-12">
        <CheckCircle className="mx-auto h-16 w-16 text-green-500 mb-4" />
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Payment Successful!</h2>
        <p className="text-gray-600 dark:text-gray-400 mb-6">
          Thank you for your purchase. Your design files will be available in your account.
        </p>
        <Link href="/client/purchases">
          <Button className="cursor-pointer">View My Purchases</Button>
        </Link>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-md">
        <PaymentElement />
      </div>

      {checkoutError && (
        <div className="bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-300 p-4 rounded-lg flex items-start">
          <AlertCircle className="h-5 w-5 mr-2 mt-0.5 flex-shrink-0" />
          <p>{checkoutError}</p>
        </div>
      )}

      <div className="flex justify-between items-center">
        <Link href="/cart">
          <div className="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-200 cursor-pointer">
            Return to cart
          </div>
        </Link>
        <Button 
          type="submit" 
          disabled={!stripe || isProcessing}
          className="min-w-[150px]"
        >
          {isProcessing ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Processing...
            </>
          ) : (
            `Pay ${new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(totalPrice / 100)}`
          )}
        </Button>
      </div>
    </form>
  );
};

export default function CheckoutPage() {
  const [clientSecret, setClientSecret] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const { items, totalPrice } = useCart();
  const [, navigate] = useLocation();

  useEffect(() => {
    // Redirect to cart if no items
    if (items.length === 0) {
      navigate('/cart');
      return;
    }

    // Create PaymentIntent as soon as the page loads
    const createPaymentIntent = async () => {
      try {
        const response = await apiRequest('POST', '/api/create-payment-intent', {
          amount: totalPrice, // This is already in cents
          items: items.map(item => ({
            id: item.product.id,
            quantity: item.quantity
          }))
        });
        
        const data = await response.json();
        setClientSecret(data.clientSecret);
      } catch (err) {
        console.error('Error creating payment intent:', err);
        setError('Unable to process payment. Please try again later.');
      }
    };

    createPaymentIntent();
  }, [items, totalPrice, navigate]);

  if (error) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.5 }}
        className="container mx-auto px-4 py-12 max-w-3xl"
      >
        <div className="bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-300 p-6 rounded-lg flex items-center">
          <AlertCircle className="h-6 w-6 mr-3 flex-shrink-0" />
          <div>
            <h2 className="text-lg font-semibold mb-1">Payment Error</h2>
            <p>{error}</p>
          </div>
        </div>
        <div className="mt-6 text-center">
          <Link href="/cart">
            <Button variant="outline" className="cursor-pointer">Return to Cart</Button>
          </Link>
        </div>
      </motion.div>
    );
  }

  if (!clientSecret) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
        className="container mx-auto px-4 py-12 flex justify-center items-center"
      >
        <div className="text-center">
          <Loader2 className="mx-auto h-8 w-8 animate-spin text-primary-600 dark:text-primary-400 mb-4" />
          <p className="text-gray-600 dark:text-gray-400">Preparing checkout...</p>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
      className="container mx-auto px-4 py-12 max-w-3xl"
    >
      <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-8">Checkout</h1>

      <div className="grid grid-cols-1 md:grid-cols-5 gap-8">
        <div className="md:col-span-3">
          <Elements stripe={stripePromise} options={{ clientSecret }}>
            <CheckoutForm />
          </Elements>
        </div>

        <div className="md:col-span-2">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">Order Summary</h2>
            
            <div className="divide-y divide-gray-200 dark:divide-gray-700">
              {items.map((item) => (
                <div key={item.product.id} className="py-3 flex justify-between">
                  <div>
                    <p className="font-medium text-gray-900 dark:text-white">{item.product.title}</p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      {item.product.fileFormats.join(", ")}
                    </p>
                  </div>
                  <p className="font-medium text-gray-900 dark:text-white">
                    {new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(item.product.price / 100)}
                  </p>
                </div>
              ))}
            </div>
            
            <div className="border-t border-gray-200 dark:border-gray-700 mt-4 pt-4">
              <div className="flex justify-between font-medium">
                <span className="text-gray-900 dark:text-white">Total</span>
                <span className="text-primary-600 dark:text-primary-400">
                  {new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(totalPrice / 100)}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}