import { motion } from "framer-motion";
import { ProductList } from "@/components/admin/product-list";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowLeft } from "lucide-react";

export default function AdminProductsPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6">
        <Link href="/admin/dashboard">
          <div className="inline-flex items-center text-gray-600 dark:text-gray-400 hover:text-primary-600 dark:hover:text-primary-400 cursor-pointer">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </div>
        </Link>
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Product Management</h1>
          <div className="flex space-x-4">
            <Button variant="outline">
              Export Products
            </Button>
          </div>
        </div>

        <div className="mb-6 p-4 bg-white dark:bg-gray-800 rounded-lg shadow">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Product Guidelines</h2>
          <ul className="list-disc list-inside text-gray-600 dark:text-gray-400 space-y-1">
            <li>All products should have high-quality images</li>
            <li>Price should be set in cents (e.g. $49.99 = 4999)</li>
            <li>Include detailed descriptions for better customer understanding</li>
            <li>Make sure to specify all available file formats</li>
            <li>Featured products appear on the homepage</li>
          </ul>
        </div>

        <ProductList />
      </motion.div>
    </div>
  );
}
