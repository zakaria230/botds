import { motion } from "framer-motion";
import { useAuth } from "@/hooks/use-auth";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  ShoppingBag, 
  Download, 
  Settings, 
  UserCircle, 
  CreditCard,
  ChevronRight
} from "lucide-react";

export default function ClientDashboardPage() {
  const { user } = useAuth();

  return (
    <div className="container mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">My Account</h1>
            <p className="text-gray-600 dark:text-gray-400">
              Welcome back, {user?.name || user?.username}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {/* Quick Stats */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Purchases</CardTitle>
              <CardDescription>Your design files</CardDescription>
            </CardHeader>
            <CardContent className="flex justify-between items-center">
              <div className="text-3xl font-bold">0</div>
              <Link href="/client/purchases">
                <a>
                  <Button variant="outline" size="sm" className="flex items-center">
                    View All
                    <ChevronRight className="ml-2 h-4 w-4" />
                  </Button>
                </a>
              </Link>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Wishlist</CardTitle>
              <CardDescription>Saved for later</CardDescription>
            </CardHeader>
            <CardContent className="flex justify-between items-center">
              <div className="text-3xl font-bold">0</div>
              <Button variant="outline" size="sm" className="flex items-center" disabled>
                View All
                <ChevronRight className="ml-2 h-4 w-4" />
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Credits</CardTitle>
              <CardDescription>Available balance</CardDescription>
            </CardHeader>
            <CardContent className="flex justify-between items-center">
              <div className="text-3xl font-bold">$0.00</div>
              <Button variant="outline" size="sm" className="flex items-center" disabled>
                Top Up
                <ChevronRight className="ml-2 h-4 w-4" />
              </Button>
            </CardContent>
          </Card>
        </div>

        <div className="mb-8">
          <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Account Management</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Link href="/client/purchases">
              <a className="block">
                <Card className="transition-all hover:shadow-md">
                  <CardContent className="p-6 flex items-center">
                    <div className="w-12 h-12 rounded-full bg-primary-100 dark:bg-primary-900 flex items-center justify-center mr-4">
                      <ShoppingBag className="h-6 w-6 text-primary-600 dark:text-primary-400" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900 dark:text-white">My Purchases</h3>
                      <p className="text-gray-600 dark:text-gray-400">View and download your purchased designs</p>
                    </div>
                  </CardContent>
                </Card>
              </a>
            </Link>

            <div>
              <Card className="transition-all">
                <CardContent className="p-6 flex items-center">
                  <div className="w-12 h-12 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center mr-4">
                    <Download className="h-6 w-6 text-gray-600 dark:text-gray-400" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Downloads</h3>
                    <p className="text-gray-600 dark:text-gray-400">No downloads available yet</p>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div>
              <Card className="transition-all">
                <CardContent className="p-6 flex items-center">
                  <div className="w-12 h-12 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center mr-4">
                    <CreditCard className="h-6 w-6 text-gray-600 dark:text-gray-400" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Payment Methods</h3>
                    <p className="text-gray-600 dark:text-gray-400">Manage your payment options</p>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div>
              <Card className="transition-all">
                <CardContent className="p-6 flex items-center">
                  <div className="w-12 h-12 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center mr-4">
                    <UserCircle className="h-6 w-6 text-gray-600 dark:text-gray-400" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Profile Settings</h3>
                    <p className="text-gray-600 dark:text-gray-400">Update your personal information</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>

        <div className="bg-primary-50 dark:bg-primary-900/20 rounded-lg p-6 border border-primary-100 dark:border-primary-800">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="mb-4 md:mb-0">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Ready to explore more designs?</h3>
              <p className="text-gray-600 dark:text-gray-400">Browse our latest digital fashion templates.</p>
            </div>
            <Link href="/shop">
              <a>
                <Button className="min-w-[150px]">Browse Shop</Button>
              </a>
            </Link>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
