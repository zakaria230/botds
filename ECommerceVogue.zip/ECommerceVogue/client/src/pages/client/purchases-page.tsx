import { motion } from "framer-motion";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Download, Search, ShoppingBag } from "lucide-react";
import { Input } from "@/components/ui/input";
import { useState } from "react";

// Mock purchases - in a real app, these would come from the API
const mockPurchases = [];

export default function ClientPurchasesPage() {
  const [searchTerm, setSearchTerm] = useState("");

  // Filter purchases based on search term
  const filteredPurchases = mockPurchases.filter(
    (purchase) => purchase.title?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6">
        <Link href="/client/dashboard">
          <a className="inline-flex items-center text-gray-600 dark:text-gray-400 hover:text-primary-600 dark:hover:text-primary-400">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </a>
        </Link>
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">My Purchases</h1>
            <p className="text-gray-600 dark:text-gray-400">
              Download and manage your purchased design files
            </p>
          </div>
          
          <div className="mt-4 md:mt-0 relative w-full md:w-64">
            <Input
              placeholder="Search purchases..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
            <Search className="h-4 w-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          </div>
        </div>

        {filteredPurchases.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredPurchases.map((purchase) => (
              <div key={purchase.id} className="bg-white dark:bg-gray-800 rounded-lg shadow overflow-hidden">
                <div className="flex">
                  <div className="w-32 h-32">
                    <img 
                      src={purchase.imageUrl} 
                      alt={purchase.title} 
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="p-4 flex-1">
                    <h3 className="font-semibold text-gray-900 dark:text-white">{purchase.title}</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Purchased on {purchase.purchaseDate}</p>
                    <div className="mt-4 flex justify-between items-center">
                      <span className="text-sm text-gray-600 dark:text-gray-400">{purchase.fileFormats.join(", ")}</span>
                      <Button size="sm" className="flex items-center">
                        <Download className="h-4 w-4 mr-2" />
                        Download
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-8 text-center">
            <div className="flex justify-center mb-4">
              <ShoppingBag className="h-16 w-16 text-gray-400 dark:text-gray-500" />
            </div>
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">No purchases yet</h2>
            <p className="text-gray-600 dark:text-gray-400 mb-6">You haven't purchased any design files yet.</p>
            <Link href="/shop">
              <a className="inline-flex items-center px-6 py-3 bg-primary-600 hover:bg-primary-700 text-white font-semibold rounded-lg transition-colors">
                Browse Shop
              </a>
            </Link>
          </div>
        )}
      </motion.div>
    </div>
  );
}
