import { motion } from "framer-motion";
import { useCart } from "@/hooks/use-cart";
import { Button } from "@/components/ui/button";
import { formatPrice } from "@/lib/utils";
import { Link } from "wouter";
import { Trash, ArrowRight, ShoppingCart } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function CartPage() {
  const { items, removeItem, totalPrice, clearCart } = useCart();
  const { toast } = useToast();

  const handleCheckout = () => {
    toast({
      title: "Checkout Processed",
      description: "Your order has been processed successfully!",
    });
    clearCart();
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
      className="container mx-auto px-4 py-12"
    >
      <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-8">Your Cart</h1>

      {items.length === 0 ? (
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-8 text-center">
          <div className="flex justify-center mb-4">
            <ShoppingCart className="h-16 w-16 text-gray-400 dark:text-gray-500" />
          </div>
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">Your cart is empty</h2>
          <p className="text-gray-600 dark:text-gray-400 mb-6">Looks like you haven't added any products to your cart yet.</p>
          <Link href="/shop">
            <a className="inline-flex items-center px-6 py-3 bg-primary-600 hover:bg-primary-700 text-white font-semibold rounded-lg transition-colors">
              Continue Shopping
              <ArrowRight className="ml-2 h-4 w-4" />
            </a>
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
              <div className="p-6 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center">
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Shopping Cart ({items.length} items)</h2>
                <Button 
                  variant="ghost" 
                  className="text-red-600 hover:text-red-800 dark:text-red-400 dark:hover:text-red-300"
                  onClick={() => clearCart()}
                >
                  Clear cart
                </Button>
              </div>
              
              <div className="divide-y divide-gray-200 dark:divide-gray-700">
                {items.map((item) => (
                  <motion.div
                    key={item.product.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3 }}
                    className="p-6 flex flex-col sm:flex-row items-start sm:items-center"
                  >
                    <div className="w-full sm:w-20 h-20 flex-shrink-0 mb-4 sm:mb-0">
                      <img 
                        src={item.product.imageUrl} 
                        alt={item.product.title} 
                        className="w-full h-full object-cover rounded-md"
                      />
                    </div>
                    <div className="flex-grow sm:ml-6">
                      <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                        <Link href={`/product/${item.product.id}`}>
                          <a className="hover:text-primary-600 dark:hover:text-primary-400">{item.product.title}</a>
                        </Link>
                      </h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                        {item.product.fileFormats.join(", ")} formats
                      </p>
                      <div className="flex items-center justify-between">
                        <div className="font-semibold text-primary-600 dark:text-primary-400">
                          {formatPrice(item.product.price)}
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeItem(item.product.id)}
                          className="text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300"
                        >
                          <Trash className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>

          <div className="lg:col-span-1">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 sticky top-20">
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-6">Order Summary</h2>
              
              <div className="space-y-4 mb-6">
                <div className="flex justify-between text-gray-600 dark:text-gray-400">
                  <span>Subtotal</span>
                  <span>{formatPrice(totalPrice)}</span>
                </div>
                
                <div className="flex justify-between text-gray-600 dark:text-gray-400">
                  <span>Tax</span>
                  <span>{formatPrice(0)}</span>
                </div>
                
                <div className="border-t border-gray-200 dark:border-gray-700 pt-4 flex justify-between font-semibold text-lg text-gray-900 dark:text-white">
                  <span>Total</span>
                  <span>{formatPrice(totalPrice)}</span>
                </div>
              </div>
              
              <Button 
                className="w-full py-6"
                onClick={handleCheckout}
              >
                Checkout
              </Button>
              
              <div className="mt-6 text-center">
                <Link href="/shop">
                  <a className="text-sm text-primary-600 dark:text-primary-400 hover:underline inline-flex items-center">
                    <ArrowRight className="h-3 w-3 mr-1 rotate-180" />
                    Continue Shopping
                  </a>
                </Link>
              </div>
            </div>
          </div>
        </div>
      )}
    </motion.div>
  );
}
