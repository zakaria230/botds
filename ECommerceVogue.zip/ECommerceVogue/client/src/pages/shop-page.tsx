import { motion } from "framer-motion";
import { ProductGrid } from "@/components/shop/product-grid";
import { useLocation } from "wouter";

export default function ShopPage() {
  const [location] = useLocation();
  const params = new URLSearchParams(location.split("?")[1] || "");
  const category = params.get("category") || "All Designs";

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
      className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12"
    >
      <ProductGrid initialCategory={category} />
    </motion.div>
  );
}
