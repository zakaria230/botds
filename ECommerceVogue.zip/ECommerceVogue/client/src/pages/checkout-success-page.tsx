import { useEffect } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Link, useLocation } from 'wouter';
import { CheckCircle, ShoppingBag } from 'lucide-react';
import { useCart } from '@/hooks/use-cart';

export default function CheckoutSuccessPage() {
  const { clearCart } = useCart();
  const [, navigate] = useLocation();
  
  useEffect(() => {
    // Clear the cart when payment is successful
    clearCart();
  }, [clearCart]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
      className="container mx-auto px-4 py-16 max-w-3xl text-center"
    >
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-8 md:p-12">
        <div className="w-16 h-16 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center mx-auto mb-6">
          <CheckCircle className="h-8 w-8 text-green-600 dark:text-green-400" />
        </div>
        
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
          Thank You for Your Purchase!
        </h1>
        
        <p className="text-gray-600 dark:text-gray-400 mb-8 max-w-md mx-auto">
          Your payment has been processed successfully. You can now access your design files in your account.
        </p>
        
        <div className="flex flex-col sm:flex-row justify-center gap-4">
          <Link href="/client/purchases">
            <Button className="w-full sm:w-auto flex items-center justify-center cursor-pointer">
              <ShoppingBag className="mr-2 h-4 w-4" />
              View My Purchases
            </Button>
          </Link>
          
          <Link href="/shop">
            <Button variant="outline" className="w-full sm:w-auto cursor-pointer">
              Continue Shopping
            </Button>
          </Link>
        </div>
      </div>
      
      <div className="mt-8 text-gray-600 dark:text-gray-400">
        <p>Need help? <Link href="/contact"><span className="text-primary-600 dark:text-primary-400 hover:underline cursor-pointer">Contact our support team</span></Link></p>
      </div>
    </motion.div>
  );
}