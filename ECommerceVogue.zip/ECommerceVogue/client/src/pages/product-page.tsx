import { useState, useEffect } from "react";
import { useRoute } from "wouter";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useCart } from "@/hooks/use-cart";
import { formatPrice, INITIAL_PRODUCTS } from "@/lib/utils";
import { Product } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";
import { getQueryFn } from "@/lib/queryClient";
import { ArrowLeft, Share2, Download, ShoppingCart } from "lucide-react";
import { Link } from "wouter";

export default function ProductPage() {
  const [, params] = useRoute<{ id: string }>("/product/:id");
  const productId = parseInt(params?.id || "0");
  const { toast } = useToast();
  const { addItem } = useCart();
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  const { data: products = INITIAL_PRODUCTS, isLoading } = useQuery<Product[]>({
    queryKey: ["/api/products"],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  const product = products.find(p => p.id === productId);
  
  useEffect(() => {
    if (product) {
      setSelectedImage(product.imageUrl);
    }
  }, [product]);

  const handleAddToCart = () => {
    if (product) {
      addItem(product);
    }
  };

  const handleShare = () => {
    if (navigator.share && product) {
      navigator.share({
        title: product.title,
        text: product.description,
        url: window.location.href,
      }).catch((error) => {
        console.log('Error sharing', error);
        copyToClipboard();
      });
    } else {
      copyToClipboard();
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(window.location.href).then(() => {
      toast({
        title: "Link copied to clipboard",
        description: "Share this link with others",
      });
    });
  };

  // Find related products (products in the same category, excluding current product)
  const relatedProducts = product 
    ? products.filter(p => p.category === product.category && p.id !== product.id).slice(0, 3)
    : [];

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-16 flex justify-center">
        <div className="animate-spin w-12 h-12 border-4 border-primary-600 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h1 className="text-3xl font-bold mb-4">Product Not Found</h1>
        <p className="mb-8">The product you're looking for doesn't exist or has been removed.</p>
        <Link href="/shop">
          <a className="px-6 py-3 bg-primary-600 text-white font-semibold rounded-lg">
            Back to Shop
          </a>
        </Link>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
      className="container mx-auto px-4 py-8 md:py-12"
    >
      <div className="mb-6">
        <Link href="/shop">
          <a className="inline-flex items-center text-gray-600 dark:text-gray-400 hover:text-primary-600 dark:hover:text-primary-400">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to shop
          </a>
        </Link>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        {/* Product Images */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="relative rounded-xl overflow-hidden shadow-lg h-[400px] md:h-[500px]">
            <img 
              src={selectedImage || product.imageUrl} 
              alt={product.title} 
              className="w-full h-full object-cover"
            />
            {product.label && (
              <div className="absolute top-4 left-4">
                <Badge className={`px-3 py-1 ${
                  product.label === "NEW" ? "bg-primary-500 hover:bg-primary-600" : 
                  product.label === "TRENDING" ? "bg-amber-500 hover:bg-amber-600" : 
                  product.label === "BESTSELLER" ? "bg-rose-500 hover:bg-rose-600" : 
                  "bg-gray-500 hover:bg-gray-600"
                }`}>
                  {product.label}
                </Badge>
              </div>
            )}
          </div>
        </motion.div>

        {/* Product Info */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
          className="flex flex-col"
        >
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">{product.title}</h1>
          <div className="mb-4">
            <span className="text-2xl font-bold text-primary-600 dark:text-primary-400">
              {formatPrice(product.price)}
            </span>
          </div>
          
          <p className="text-gray-600 dark:text-gray-400 mb-6">{product.description}</p>
          
          <div className="mb-6">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">File Formats</h3>
            <div className="flex flex-wrap gap-2">
              {product.fileFormats.map((format, index) => (
                <Badge key={index} variant="outline" className="px-3 py-1">
                  {format}
                </Badge>
              ))}
            </div>
          </div>
          
          <Tabs defaultValue="details" className="mb-8">
            <TabsList className="mb-2">
              <TabsTrigger value="details">Details</TabsTrigger>
              <TabsTrigger value="usage">Usage Rights</TabsTrigger>
            </TabsList>
            <TabsContent value="details" className="text-gray-600 dark:text-gray-400">
              <ul className="list-disc list-inside space-y-1">
                <li>High-resolution files optimized for professional use</li>
                <li>Compatible with major design software (Adobe Photoshop, Illustrator)</li>
                <li>Layered files for easy customization</li>
                <li>Digital format - no physical product will be shipped</li>
              </ul>
            </TabsContent>
            <TabsContent value="usage" className="text-gray-600 dark:text-gray-400">
              <ul className="list-disc list-inside space-y-1">
                <li>Personal and commercial use allowed</li>
                <li>Unlimited print-on-demand products</li>
                <li>Cannot be resold as-is or without significant modification</li>
                <li>Cannot be redistributed as design templates</li>
              </ul>
            </TabsContent>
          </Tabs>
          
          <div className="mt-auto space-y-4">
            <Button 
              className="w-full flex items-center justify-center text-lg h-12"
              onClick={handleAddToCart}
            >
              <ShoppingCart className="mr-2 h-5 w-5" />
              Add to Cart
            </Button>
            
            <div className="flex gap-4">
              <Button 
                variant="outline" 
                className="flex-1 flex items-center justify-center"
                onClick={handleShare}
              >
                <Share2 className="mr-2 h-4 w-4" />
                Share
              </Button>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Related Products */}
      {relatedProducts.length > 0 && (
        <div className="mt-16">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Related Products</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            {relatedProducts.map((relatedProduct) => (
              <motion.div
                key={relatedProduct.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="group bg-white dark:bg-gray-800 rounded-xl overflow-hidden shadow-md hover:shadow-xl"
                whileHover={{ y: -5 }}
              >
                <Link href={`/product/${relatedProduct.id}`}>
                  <a className="block">
                    <div className="relative overflow-hidden h-48">
                      <img 
                        src={relatedProduct.imageUrl} 
                        alt={relatedProduct.title} 
                        className="w-full h-full object-cover object-center transform group-hover:scale-105 transition-transform duration-500"
                      />
                    </div>
                    <div className="p-4">
                      <h3 className="text-lg font-semibold text-gray-900 dark:text-white">{relatedProduct.title}</h3>
                      <div className="mt-2 flex items-center justify-between">
                        <span className="text-primary-600 dark:text-primary-400 font-bold">{formatPrice(relatedProduct.price)}</span>
                        <span className="text-sm text-gray-500 dark:text-gray-400">{relatedProduct.category}</span>
                      </div>
                    </div>
                  </a>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      )}
    </motion.div>
  );
}
