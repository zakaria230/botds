import { useState } from "react";
import { Link, useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Moon, Sun, Menu, ShoppingBag, User, X } from "lucide-react";
import { useTheme } from "@/hooks/use-theme";
import { useCart } from "@/hooks/use-cart";
import { useAuth } from "@/hooks/use-auth";

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { theme, setTheme } = useTheme();
  const { totalItems, setIsCartOpen } = useCart();
  const { user, logoutMutation } = useAuth();
  const [location] = useLocation();

  const isActive = (path: string) => {
    return location === path;
  };

  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark");
  };

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const openCart = () => {
    setIsCartOpen(true);
  };

  const handleSignOut = () => {
    logoutMutation.mutate();
  };

  return (
    <header className="sticky top-0 z-50 bg-white dark:bg-gray-900 shadow-sm transition-all duration-300">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <nav className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <div className="flex-shrink-0 flex items-center">
            <Link href="/">
              <div className="text-primary-600 dark:text-primary-400 font-bold text-xl tracking-tight cursor-pointer">
                Design<span className="text-gray-900 dark:text-white">Korv</span>
              </div>
            </Link>
          </div>
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <Link href="/">
              <div className={`font-medium ${isActive("/") ? "text-gray-900 dark:text-white" : "text-gray-500 dark:text-gray-300"} hover:text-primary-600 dark:hover:text-primary-400 transition-colors cursor-pointer`}>
                Home
              </div>
            </Link>
            <Link href="/shop">
              <div className={`font-medium ${isActive("/shop") ? "text-gray-900 dark:text-white" : "text-gray-500 dark:text-gray-300"} hover:text-primary-600 dark:hover:text-primary-400 transition-colors cursor-pointer`}>
                Shop
              </div>
            </Link>
            <Link href="/about">
              <div className={`font-medium ${isActive("/about") ? "text-gray-900 dark:text-white" : "text-gray-500 dark:text-gray-300"} hover:text-primary-600 dark:hover:text-primary-400 transition-colors cursor-pointer`}>
                About
              </div>
            </Link>
            <Link href="/contact">
              <div className={`font-medium ${isActive("/contact") ? "text-gray-900 dark:text-white" : "text-gray-500 dark:text-gray-300"} hover:text-primary-600 dark:hover:text-primary-400 transition-colors cursor-pointer`}>
                Contact
              </div>
            </Link>
          </div>
          
          {/* User & Cart Actions */}
          <div className="flex items-center space-x-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleTheme}
              className="p-2 rounded-full text-gray-500 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800"
              aria-label="Toggle theme"
            >
              {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </Button>
            
            {user ? (
              <div className="relative group dropdown-container">
                <Button
                  variant="ghost"
                  size="icon"
                  className="p-2 rounded-full text-gray-500 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800"
                  aria-label="User menu"
                >
                  <User className="h-5 w-5" />
                </Button>
                <div className="absolute right-0 mt-2 w-48 rounded-md shadow-lg py-1 bg-white dark:bg-gray-800 ring-1 ring-black ring-opacity-5 dropdown-menu opacity-0 invisible transform translate-y-2 pointer-events-none transition-all duration-200 ease-in-out group-hover:opacity-100 group-hover:visible group-hover:translate-y-0 group-hover:pointer-events-auto z-50">
                  <Link href={user.isAdmin ? "/admin/dashboard" : "/client/dashboard"}>
                    <div className="block px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700 cursor-pointer">
                      Dashboard
                    </div>
                  </Link>
                  {user.isAdmin && (
                    <Link href="/admin/products">
                      <div className="block px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700 cursor-pointer">
                        Manage Products
                      </div>
                    </Link>
                  )}
                  <button
                    onClick={handleSignOut}
                    className="block w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700"
                  >
                    Sign Out
                  </button>
                </div>
              </div>
            ) : (
              <Link href="/auth">
                <div className="p-2 rounded-full text-gray-500 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors cursor-pointer">
                  <User className="h-5 w-5" />
                </div>
              </Link>
            )}
            
            <div className="relative">
              <Button
                variant="ghost"
                size="icon"
                onClick={openCart}
                className="p-2 rounded-full text-gray-500 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800"
                aria-label="Open cart"
              >
                <ShoppingBag className="h-5 w-5" />
              </Button>
              {totalItems > 0 && (
                <span className="absolute -top-1 -right-1 bg-primary-500 text-white text-xs font-medium px-1.5 py-0.5 rounded-full">
                  {totalItems}
                </span>
              )}
            </div>
            
            {/* Mobile Menu Button */}
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleMenu}
              className="md:hidden p-2 rounded-full text-gray-500 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800"
              aria-label="Toggle menu"
            >
              {isMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </nav>
      </div>
      
      {/* Mobile Navigation */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            className="md:hidden bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-800 px-4 py-3"
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <div className="flex flex-col space-y-3">
              <Link href="/">
                <div className={`font-medium ${isActive("/") ? "text-gray-900 dark:text-white" : "text-gray-500 dark:text-gray-300"} py-2 cursor-pointer`} onClick={() => setIsMenuOpen(false)}>
                  Home
                </div>
              </Link>
              <Link href="/shop">
                <div className={`font-medium ${isActive("/shop") ? "text-gray-900 dark:text-white" : "text-gray-500 dark:text-gray-300"} py-2 cursor-pointer`} onClick={() => setIsMenuOpen(false)}>
                  Shop
                </div>
              </Link>
              <Link href="/about">
                <div className={`font-medium ${isActive("/about") ? "text-gray-900 dark:text-white" : "text-gray-500 dark:text-gray-300"} py-2 cursor-pointer`} onClick={() => setIsMenuOpen(false)}>
                  About
                </div>
              </Link>
              <Link href="/contact">
                <div className={`font-medium ${isActive("/contact") ? "text-gray-900 dark:text-white" : "text-gray-500 dark:text-gray-300"} py-2 cursor-pointer`} onClick={() => setIsMenuOpen(false)}>
                  Contact
                </div>
              </Link>
              {!user && (
                <Link href="/auth">
                  <div className="font-medium text-gray-500 dark:text-gray-300 py-2 cursor-pointer" onClick={() => setIsMenuOpen(false)}>
                    Sign In
                  </div>
                </Link>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
