import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { useCart } from "@/hooks/use-cart";
import { X, Trash } from "lucide-react";
import { formatPrice } from "@/lib/utils";
import { Link } from "wouter";

export function CartSidebar() {
  const { items, removeItem, totalPrice, isCartOpen, setIsCartOpen } = useCart();

  const closeCart = () => {
    setIsCartOpen(false);
  };

  return (
    <>
      <AnimatePresence>
        {isCartOpen && (
          <motion.div
            className="fixed inset-0 bg-black bg-opacity-50 z-40"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={closeCart}
          />
        )}
      </AnimatePresence>
      
      <AnimatePresence>
        {isCartOpen && (
          <motion.div
            className="fixed top-0 right-0 w-full md:w-96 h-full bg-white dark:bg-gray-900 z-50 shadow-2xl overflow-y-auto"
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
          >
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-bold text-gray-900 dark:text-white">Your Cart ({items.length})</h3>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={closeCart}
                  className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800"
                >
                  <X className="h-5 w-5" />
                </Button>
              </div>
              
              {items.length > 0 ? (
                <div className="space-y-4 mb-6">
                  {items.map((item) => (
                    <div key={item.product.id} className="flex items-start border-b border-gray-200 dark:border-gray-800 pb-4">
                      <img 
                        src={item.product.imageUrl} 
                        alt={item.product.title} 
                        className="w-16 h-16 object-cover rounded"
                      />
                      <div className="ml-4 flex-grow">
                        <h4 className="text-sm font-medium text-gray-900 dark:text-white">{item.product.title}</h4>
                        <p className="text-xs text-gray-500 dark:text-gray-400">
                          {item.product.fileFormats.join(", ")} formats
                        </p>
                        <div className="flex justify-between items-center mt-2">
                          <span className="text-sm font-bold text-primary-600 dark:text-primary-400">
                            {formatPrice(item.product.price)}
                          </span>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => removeItem(item.product.id)}
                            className="text-gray-400 hover:text-red-500"
                          >
                            <Trash className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <p className="text-gray-500 dark:text-gray-400 mb-4">Your cart is empty</p>
                  <Button
                    variant="outline"
                    onClick={closeCart}
                  >
                    Continue Shopping
                  </Button>
                </div>
              )}
              
              {items.length > 0 && (
                <div className="border-t border-gray-200 dark:border-gray-800 pt-4 pb-6">
                  <div className="flex justify-between items-center mb-4">
                    <span className="text-gray-600 dark:text-gray-400">Subtotal</span>
                    <span className="text-lg font-bold text-gray-900 dark:text-white">{formatPrice(totalPrice)}</span>
                  </div>
                  <Link href="/checkout">
                    <Button
                      onClick={closeCart}
                      className="w-full py-3 px-4 bg-primary-600 hover:bg-primary-700 text-white text-center font-semibold rounded-lg shadow-md hover:shadow-lg cursor-pointer"
                    >
                      Proceed to Checkout
                    </Button>
                  </Link>
                  <Button
                    variant="outline"
                    onClick={closeCart}
                    className="w-full mt-3 py-3 px-4 bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 text-gray-800 dark:text-white text-center font-semibold rounded-lg"
                  >
                    Continue Shopping
                  </Button>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
