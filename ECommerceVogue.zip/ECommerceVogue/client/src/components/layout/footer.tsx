import { Link } from "wouter";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Instagram, Dribbble, Send, Twitter, Facebook } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-gray-900 dark:bg-gray-950 text-white pt-16 pb-8">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {/* Company Info */}
          <div>
            <h3 className="text-xl font-bold mb-4">DesignKorv</h3>
            <p className="text-gray-400 mb-4">Premium digital clothing design files for fashion creators and brands.</p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Dribbble className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/">
                  <span className="text-gray-400 hover:text-white transition-colors cursor-pointer">Home</span>
                </Link>
              </li>
              <li>
                <Link href="/shop">
                  <span className="text-gray-400 hover:text-white transition-colors cursor-pointer">Shop</span>
                </Link>
              </li>
              <li>
                <Link href="/about">
                  <span className="text-gray-400 hover:text-white transition-colors cursor-pointer">About Us</span>
                </Link>
              </li>
              <li>
                <Link href="/contact">
                  <span className="text-gray-400 hover:text-white transition-colors cursor-pointer">Contact</span>
                </Link>
              </li>
              <li>
                <Link href="/blog">
                  <span className="text-gray-400 hover:text-white transition-colors cursor-pointer">Blog</span>
                </Link>
              </li>
            </ul>
          </div>
          
          {/* Categories */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Categories</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/shop?category=T-shirts">
                  <span className="text-gray-400 hover:text-white transition-colors cursor-pointer">T-shirts</span>
                </Link>
              </li>
              <li>
                <Link href="/shop?category=Hoodies">
                  <span className="text-gray-400 hover:text-white transition-colors cursor-pointer">Hoodies</span>
                </Link>
              </li>
              <li>
                <Link href="/shop?category=Streetwear">
                  <span className="text-gray-400 hover:text-white transition-colors cursor-pointer">Streetwear</span>
                </Link>
              </li>
              <li>
                <Link href="/shop?category=Jackets">
                  <span className="text-gray-400 hover:text-white transition-colors cursor-pointer">Jackets</span>
                </Link>
              </li>
              <li>
                <Link href="/shop?category=Accessories">
                  <span className="text-gray-400 hover:text-white transition-colors cursor-pointer">Accessories</span>
                </Link>
              </li>
            </ul>
          </div>
          
          {/* Newsletter */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Newsletter</h3>
            <p className="text-gray-400 mb-4">Subscribe to get the latest updates on new designs and special offers.</p>
            <form className="flex" onSubmit={(e) => e.preventDefault()}>
              <Input
                type="email"
                placeholder="Your email"
                className="px-4 py-2 rounded-l-lg bg-gray-800 border border-gray-700 text-white focus:outline-none focus:ring-1 focus:ring-primary-500 w-full"
                required
              />
              <Button
                type="submit"
                className="px-4 py-2 bg-primary-600 hover:bg-primary-700 text-white rounded-r-lg transition-colors"
              >
                <Send className="h-4 w-4" />
              </Button>
            </form>
          </div>
        </div>
        
        <div className="border-t border-gray-800 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-500 text-sm mb-4 md:mb-0">
              &copy; {new Date().getFullYear()} DesignKorv. All rights reserved.
            </p>
            <div className="flex space-x-6">
              <Link href="/privacy">
                <span className="text-gray-500 text-sm hover:text-gray-400 transition-colors cursor-pointer">Privacy Policy</span>
              </Link>
              <Link href="/terms">
                <span className="text-gray-500 text-sm hover:text-gray-400 transition-colors cursor-pointer">Terms of Service</span>
              </Link>
              <Link href="/refund">
                <span className="text-gray-500 text-sm hover:text-gray-400 transition-colors cursor-pointer">Refund Policy</span>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
