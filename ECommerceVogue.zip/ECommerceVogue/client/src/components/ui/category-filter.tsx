import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { PRODUCT_CATEGORIES } from "@/lib/utils";

interface CategoryFilterProps {
  selectedCategory: string;
  onSelectCategory: (category: string) => void;
}

export function CategoryFilter({ selectedCategory, onSelectCategory }: CategoryFilterProps) {
  return (
    <div className="flex flex-wrap justify-center mb-8 gap-2">
      {PRODUCT_CATEGORIES.map((category) => (
        <motion.div
          key={category}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onSelectCategory(category)}
            className={`rounded-full ${
              selectedCategory === category
                ? "bg-primary-100 dark:bg-primary-900 text-primary-600 dark:text-primary-300 font-medium"
                : "bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 font-medium hover:bg-gray-200 dark:hover:bg-gray-700"
            }`}
          >
            {category}
          </Button>
        </motion.div>
      ))}
    </div>
  );
}
