import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Product } from "@shared/schema";
import { formatPrice } from "@/lib/utils";
import { useCart } from "@/hooks/use-cart";
import { Link } from "wouter";

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  const { addItem } = useCart();

  return (
    <motion.div
      className="group bg-white dark:bg-gray-800 rounded-xl overflow-hidden shadow-md hover:shadow-xl transition-all"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      whileHover={{ y: -5 }}
    >
      <div className="relative overflow-hidden">
        {product.label && (
          <div className="absolute top-2 left-2 z-10">
            <span className={`inline-block px-2 py-1 ${
              product.label === "NEW" ? "bg-primary-500" : 
              product.label === "TRENDING" ? "bg-amber-500" : 
              product.label === "BESTSELLER" ? "bg-rose-500" : "bg-gray-500"
            } text-white text-xs font-semibold rounded`}>
              {product.label}
            </span>
          </div>
        )}
        <Link href={`/product/${product.id}`}>
          <div className="cursor-pointer">
            <img 
              src={product.imageUrl} 
              alt={product.title} 
              className="w-full h-64 object-cover object-center transform group-hover:scale-105 transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-black opacity-0 group-hover:opacity-10 transition-opacity"></div>
          </div>
        </Link>
      </div>
      <div className="p-5">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
          <Link href={`/product/${product.id}`}>
            <span className="hover:text-primary-600 dark:hover:text-primary-400 transition-colors cursor-pointer">
              {product.title}
            </span>
          </Link>
        </h3>
        <p className="mt-2 text-sm text-gray-600 dark:text-gray-400">{product.description}</p>
        <div className="mt-3 flex items-center justify-between">
          <span className="text-primary-600 dark:text-primary-400 font-bold">{formatPrice(product.price)}</span>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => addItem(product)}
            className="bg-gray-100 dark:bg-gray-700 hover:bg-primary-100 dark:hover:bg-primary-900 text-gray-800 dark:text-gray-200 hover:text-primary-600 dark:hover:text-primary-400 rounded-lg transition-colors"
          >
            Add to Cart
          </Button>
        </div>
      </div>
    </motion.div>
  );
}
