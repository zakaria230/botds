import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { insertProductSchema, Product } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { PRODUCT_CATEGORIES } from "@/lib/utils";
import { useMutation } from "@tanstack/react-query";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { X } from "lucide-react";

const validationSchema = insertProductSchema.extend({
  price: z.preprocess(
    (val) => (typeof val === 'string' ? parseFloat(val) * 100 : val as number),
    z.number().min(1, "Price must be greater than 0")
  ),
  fileFormats: z.array(z.string()).min(1, "At least one file format is required"),
});

type ProductFormValues = z.infer<typeof validationSchema>;

interface ProductFormProps {
  product?: Product;
  onSuccess?: () => void;
}

export function ProductForm({ product, onSuccess }: ProductFormProps) {
  const { toast } = useToast();
  const [selectedFormats, setSelectedFormats] = useState<string[]>(
    product?.fileFormats || []
  );
  const [selectedCategory, setSelectedCategory] = useState<string>(
    product?.category || "T-shirts"
  );
  const [selectedLabel, setSelectedLabel] = useState<string>(
    product?.label || ""
  );

  const { register, handleSubmit, formState: { errors }, setValue, watch } = useForm<ProductFormValues>({
    resolver: zodResolver(validationSchema),
    defaultValues: {
      title: product?.title || "",
      description: product?.description || "",
      price: product ? product.price / 100 : 0,
      imageUrl: product?.imageUrl || "",
      fileUrl: product?.fileUrl || "",
      fileFormats: product?.fileFormats || [],
      category: product?.category || "T-shirts",
      featured: product?.featured || false,
      label: product?.label || "",
    },
  });

  useEffect(() => {
    setValue("category", selectedCategory);
  }, [selectedCategory, setValue]);

  useEffect(() => {
    setValue("label", selectedLabel);
  }, [selectedLabel, setValue]);

  useEffect(() => {
    setValue("fileFormats", selectedFormats);
  }, [selectedFormats, setValue]);

  const createProductMutation = useMutation({
    mutationFn: async (data: ProductFormValues) => {
      const response = await apiRequest("POST", "/api/products", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      toast({
        title: "Product created",
        description: "The product has been successfully created.",
      });
      if (onSuccess) onSuccess();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create product",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateProductMutation = useMutation({
    mutationFn: async (data: ProductFormValues) => {
      const response = await apiRequest("PATCH", `/api/products/${product?.id}`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      toast({
        title: "Product updated",
        description: "The product has been successfully updated.",
      });
      if (onSuccess) onSuccess();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update product",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: ProductFormValues) => {
    if (product) {
      updateProductMutation.mutate({
        ...data,
        fileFormats: selectedFormats,
        category: selectedCategory,
        label: selectedLabel
      });
    } else {
      createProductMutation.mutate({
        ...data,
        fileFormats: selectedFormats,
        category: selectedCategory,
        label: selectedLabel
      });
    }
  };

  const handleFormatToggle = (format: string) => {
    setSelectedFormats(prevFormats => {
      if (prevFormats.includes(format)) {
        return prevFormats.filter(f => f !== format);
      } else {
        return [...prevFormats, format];
      }
    });
  };

  const availableFormats = ["AI", "PSD", "PNG", "JPG", "SVG", "PDF"];
  const productCategories = PRODUCT_CATEGORIES.filter(cat => cat !== "All Designs");
  const labels = [
    { value: "", display: "None" },
    { value: "NEW", display: "NEW" },
    { value: "TRENDING", display: "TRENDING" },
    { value: "BESTSELLER", display: "BESTSELLER" },
    { value: "SALE", display: "SALE" }
  ];

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      <div className="space-y-4">
        <div>
          <Label htmlFor="title">Title</Label>
          <Input id="title" {...register("title")} />
          {errors.title && (
            <p className="text-sm text-red-500 mt-1">{errors.title.message}</p>
          )}
        </div>

        <div>
          <Label htmlFor="description">Description</Label>
          <Textarea id="description" {...register("description")} />
          {errors.description && (
            <p className="text-sm text-red-500 mt-1">{errors.description.message}</p>
          )}
        </div>

        <div>
          <Label htmlFor="price">Price ($)</Label>
          <Input
            id="price"
            type="number"
            step="0.01"
            {...register("price")}
          />
          {errors.price && (
            <p className="text-sm text-red-500 mt-1">{errors.price.message}</p>
          )}
        </div>

        <div>
          <Label htmlFor="imageUrl">Image URL</Label>
          <Input id="imageUrl" {...register("imageUrl")} />
          {errors.imageUrl && (
            <p className="text-sm text-red-500 mt-1">{errors.imageUrl.message}</p>
          )}
        </div>

        <div>
          <Label htmlFor="fileUrl">File URL</Label>
          <Input id="fileUrl" {...register("fileUrl")} />
          {errors.fileUrl && (
            <p className="text-sm text-red-500 mt-1">{errors.fileUrl.message}</p>
          )}
        </div>

        <div>
          <Label>File Formats</Label>
          <div className="flex flex-wrap gap-2 mt-2">
            {availableFormats.map((format) => (
              <div
                key={format}
                className={`px-3 py-1 rounded-full cursor-pointer text-sm ${
                  selectedFormats.includes(format)
                    ? "bg-primary-100 text-primary-800 dark:bg-primary-900 dark:text-primary-300"
                    : "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300"
                }`}
                onClick={() => handleFormatToggle(format)}
              >
                {format}
                {selectedFormats.includes(format) && (
                  <X className="h-3 w-3 ml-1 inline" />
                )}
              </div>
            ))}
          </div>
          {errors.fileFormats && (
            <p className="text-sm text-red-500 mt-1">{errors.fileFormats.message}</p>
          )}
        </div>

        <div>
          <Label htmlFor="category">Category</Label>
          <div className="relative">
            <select 
              className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2"
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
            >
              {productCategories.map((category) => (
                <option key={category} value={category}>
                  {category}
                </option>
              ))}
            </select>
          </div>
          {errors.category && (
            <p className="text-sm text-red-500 mt-1">{errors.category.message}</p>
          )}
        </div>

        <div>
          <Label htmlFor="label">Label</Label>
          <div className="relative">
            <select 
              className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2"
              value={selectedLabel}
              onChange={(e) => setSelectedLabel(e.target.value)}
            >
              {labels.map((label) => (
                <option key={label.value || "none"} value={label.value}>
                  {label.display}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <Checkbox
            id="featured"
            checked={watch("featured")}
            onCheckedChange={(checked) => 
              setValue("featured", checked as boolean)
            }
          />
          <Label htmlFor="featured">Featured product</Label>
        </div>
      </div>

      <Button
        type="submit"
        disabled={createProductMutation.isPending || updateProductMutation.isPending}
      >
        {createProductMutation.isPending || updateProductMutation.isPending
          ? "Saving..."
          : product
          ? "Update Product"
          : "Create Product"}
      </Button>
    </form>
  );
}
