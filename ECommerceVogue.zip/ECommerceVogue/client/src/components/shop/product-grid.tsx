import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { ProductCard } from "@/components/ui/product-card";
import { CategoryFilter } from "@/components/ui/category-filter";
import { Product } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";
import { getQueryFn } from "@/lib/queryClient";
import { INITIAL_PRODUCTS } from "@/lib/utils";

interface ProductGridProps {
  initialCategory?: string;
}

export function ProductGrid({ initialCategory = "All Designs" }: ProductGridProps) {
  const [selectedCategory, setSelectedCategory] = useState(initialCategory);
  
  const { data: products = INITIAL_PRODUCTS, isLoading } = useQuery<Product[]>({
    queryKey: ["/api/products"],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  // Update category if URL parameter changes
  useEffect(() => {
    setSelectedCategory(initialCategory);
  }, [initialCategory]);

  const filteredProducts = selectedCategory === "All Designs"
    ? products
    : products.filter(product => product.category === selectedCategory);

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.3,
      },
    },
  };

  return (
    <div>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="mb-8"
      >
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4 text-center">
          Digital Clothing Designs
        </h1>
        <p className="text-gray-600 dark:text-gray-400 max-w-3xl mx-auto text-center mb-8">
          Browse our collection of high-quality digital clothing templates, ready for download and customization.
        </p>
      </motion.div>

      <CategoryFilter
        selectedCategory={selectedCategory}
        onSelectCategory={setSelectedCategory}
      />

      {isLoading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
        </div>
      ) : filteredProducts.length > 0 ? (
        <motion.div
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8"
          variants={container}
          initial="hidden"
          animate="show"
        >
          {filteredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </motion.div>
      ) : (
        <div className="text-center py-16">
          <h3 className="text-xl font-medium text-gray-900 dark:text-white mb-2">No products found</h3>
          <p className="text-gray-600 dark:text-gray-400">
            We couldn't find any products in the "{selectedCategory}" category.
          </p>
        </div>
      )}
    </div>
  );
}
