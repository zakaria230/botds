import { motion } from "framer-motion";
import { Link } from "wouter";

export function AboutSection() {
  return (
    <section id="about" className="py-16 bg-white dark:bg-gray-900">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">About DesignKorv</h2>
            <p className="text-gray-600 dark:text-gray-400 mb-6">
              Founded in 2020, DesignKorv was created by a team of fashion designers and digital artists with a mission to make high-quality fashion design templates accessible to everyone.
            </p>
            <p className="text-gray-600 dark:text-gray-400 mb-6">
              We believe that great design should not be a barrier to entry for aspiring fashion brands and independent designers. Our templates are crafted with attention to detail and industry standards.
            </p>
            <div className="flex flex-wrap gap-4 mt-8">
              <Link href="/contact">
                <div className="px-6 py-3 bg-gray-900 dark:bg-white text-white dark:text-gray-900 font-semibold rounded-lg shadow-md hover:bg-gray-800 dark:hover:bg-gray-100 transition-colors cursor-pointer">
                  Contact Us
                </div>
              </Link>
              <Link href="/shop">
                <div className="px-6 py-3 bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-white font-semibold rounded-lg shadow-md hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors cursor-pointer">
                  Browse Designs
                </div>
              </Link>
            </div>
          </motion.div>
          
          <motion.div
            className="grid grid-cols-2 gap-4"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
          >
            <motion.div
              className="rounded-xl overflow-hidden shadow-lg"
              whileHover={{ scale: 1.05 }}
              transition={{ duration: 0.3 }}
            >
              <img 
                src="https://images.unsplash.com/photo-1621600411688-4be93c2c1208?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80" 
                alt="Designer workspace" 
                className="w-full h-full object-cover"
              />
            </motion.div>
            <motion.div
              className="rounded-xl overflow-hidden shadow-lg transform translate-y-8"
              whileHover={{ scale: 1.05 }}
              transition={{ duration: 0.3 }}
            >
              <img 
                src="https://images.unsplash.com/photo-1558655146-9f40138edfeb?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80" 
                alt="Design process" 
                className="w-full h-full object-cover"
              />
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
