import { useState } from "react";
import { motion } from "framer-motion";
import { Link } from "wouter";
import { ProductCard } from "@/components/ui/product-card";
import { CategoryFilter } from "@/components/ui/category-filter";
import { ArrowRight } from "lucide-react";
import { INITIAL_PRODUCTS } from "@/lib/utils";
import { useQuery } from "@tanstack/react-query";
import { getQueryFn } from "@/lib/queryClient";
import { Product } from "@shared/schema";

export function FeaturedProducts() {
  const [selectedCategory, setSelectedCategory] = useState("All Designs");

  const { data: products = INITIAL_PRODUCTS, isLoading } = useQuery<Product[]>({
    queryKey: ["/api/products"],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  const filteredProducts = selectedCategory === "All Designs"
    ? products
    : products.filter(product => product.category === selectedCategory);

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.3,
      },
    },
  };

  return (
    <section id="shop" className="py-16 bg-white dark:bg-gray-900">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          className="mb-12 text-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">Featured Designs</h2>
          <p className="text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">Our most popular digital clothing templates, ready for download and customization.</p>
        </motion.div>
        
        {/* Category Filters */}
        <CategoryFilter
          selectedCategory={selectedCategory}
          onSelectCategory={setSelectedCategory}
        />
        
        {/* Product Grid */}
        {isLoading ? (
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
          </div>
        ) : (
          <motion.div
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8"
            variants={container}
            initial="hidden"
            animate="show"
          >
            {filteredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </motion.div>
        )}
        
        <motion.div
          className="mt-12 text-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.6 }}
        >
          <Link href="/shop">
            <div className="inline-block px-8 py-3 bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 text-gray-800 dark:text-white font-semibold rounded-lg transition-colors cursor-pointer">
              View All Designs
              <ArrowRight className="ml-1 inline-block h-4 w-4" />
            </div>
          </Link>
        </motion.div>
      </div>
    </section>
  );
}
