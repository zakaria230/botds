import { Link } from "wouter";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";

export function HeroSection() {
  return (
    <section className="relative bg-gradient-to-br from-gray-50 via-white to-gray-100 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 overflow-hidden">
      <div className="absolute inset-0 opacity-70 bg-pattern"></div>
      
      <div className="relative container mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24 lg:py-32">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <motion.h1
              className="text-4xl md:text-5xl lg:text-6xl font-extrabold text-gray-900 dark:text-white leading-tight"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, ease: "easeOut" }}
            >
              Design. <span className="text-primary-600 dark:text-primary-400">Sell.</span> Repeat.
            </motion.h1>
            
            <motion.p
              className="mt-4 text-xl text-gray-600 dark:text-gray-300 max-w-xl"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1, ease: "easeOut" }}
            >
              Premium digital clothing design files for fashion creators and brands. Ready to use, easy to customize.
            </motion.p>
            
            <motion.div
              className="mt-8 flex flex-wrap gap-4"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2, ease: "easeOut" }}
            >
              <Link href="/shop">
                <div className="px-8 py-3 bg-primary-600 hover:bg-primary-700 text-white font-semibold rounded-lg shadow-lg hover:shadow-xl transition-all duration-300 flex items-center cursor-pointer">
                  Browse Designs
                  <ArrowRight className="ml-2 h-4 w-4" />
                </div>
              </Link>
              <a href="#how-it-works" className="px-8 py-3 bg-white dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-800 dark:text-gray-200 font-semibold rounded-lg shadow-md hover:shadow-lg transition-all duration-300">
                How It Works
              </a>
            </motion.div>
            
            <motion.div
              className="mt-8 flex items-center space-x-4"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3, ease: "easeOut" }}
            >
              <span className="text-sm font-medium text-gray-600 dark:text-gray-400">Trusted by designers from:</span>
              <div className="flex space-x-4">
                <img src="https://via.placeholder.com/100x40?text=Logo1" alt="Company logo" className="h-8 w-auto grayscale opacity-70 hover:grayscale-0 hover:opacity-100 transition-all" />
                <img src="https://via.placeholder.com/100x40?text=Logo2" alt="Company logo" className="h-8 w-auto grayscale opacity-70 hover:grayscale-0 hover:opacity-100 transition-all" />
                <img src="https://via.placeholder.com/100x40?text=Logo3" alt="Company logo" className="h-8 w-auto grayscale opacity-70 hover:grayscale-0 hover:opacity-100 transition-all" />
              </div>
            </motion.div>
          </div>
          
          <div className="relative">
            <motion.div
              className="absolute -top-16 -left-16 w-32 h-32 bg-primary-400 opacity-20 rounded-full filter blur-xl"
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
            />
            <motion.div
              className="absolute -bottom-8 -right-8 w-24 h-24 bg-amber-400 opacity-20 rounded-full filter blur-xl"
              animate={{ scale: [1, 1.3, 1] }}
              transition={{ duration: 5, delay: 1, repeat: Infinity, ease: "easeInOut" }}
            />
            
            <motion.div
              className="relative rounded-2xl overflow-hidden shadow-2xl transform rotate-2 hover:rotate-0 transition-transform duration-500 z-10"
              initial={{ opacity: 0, rotate: 2, y: 50 }}
              animate={{ opacity: 1, rotate: 2, y: 0 }}
              transition={{ duration: 0.8, ease: "easeOut" }}
              whileHover={{ rotate: 0, scale: 1.03 }}
            >
              <img 
                src="https://images.unsplash.com/photo-1561070791-2526d30994b5?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
                alt="Digital fashion design showcase" 
                className="w-full h-auto object-cover"
              />
            </motion.div>
            
            <motion.div
              className="absolute -bottom-6 -left-6 rounded-2xl overflow-hidden shadow-xl transform -rotate-3 hover:rotate-0 transition-transform duration-500 w-24 h-24 md:w-32 md:h-32 z-0"
              initial={{ opacity: 0, rotate: -3, x: -20 }}
              animate={{ opacity: 1, rotate: -3, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2, ease: "easeOut" }}
              whileHover={{ rotate: 0, scale: 1.05 }}
            >
              <img 
                src="https://images.unsplash.com/photo-1516762689617-e1cffcef479d?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80" 
                alt="Fashion design detail" 
                className="w-full h-full object-cover"
              />
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}
