import { Switch, Route } from "wouter";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { CartSidebar } from "@/components/layout/cart-sidebar";
import { ProtectedRoute } from "@/lib/protected-route";
import HomePage from "@/pages/home-page";
import ShopPage from "@/pages/shop-page";
import ProductPage from "@/pages/product-page";
import AuthPage from "@/pages/auth-page";
import CartPage from "@/pages/cart-page";
import CheckoutPage from "@/pages/checkout-page";
import CheckoutSuccessPage from "@/pages/checkout-success-page";
import AboutPage from "@/pages/about-page";
import ContactPage from "@/pages/contact-page";
import NotFound from "@/pages/not-found";
import AdminLoginPage from "@/pages/admin/login-page";
import AdminDashboardPage from "@/pages/admin/dashboard-page";
import AdminProductsPage from "@/pages/admin/products-page";
import AdminSettingsPage from "@/pages/admin/settings-page";
import ClientDashboardPage from "@/pages/client/dashboard-page";
import ClientPurchasesPage from "@/pages/client/purchases-page";

function App() {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      <main className="flex-grow">
        <Switch>
          <Route path="/" component={HomePage} />
          <Route path="/shop" component={ShopPage} />
          <Route path="/product/:id" component={ProductPage} />
          <Route path="/about" component={AboutPage} />
          <Route path="/contact" component={ContactPage} />
          <Route path="/auth" component={AuthPage} />
          <Route path="/cart" component={CartPage} />
          <Route path="/checkout" component={CheckoutPage} />
          <Route path="/checkout/success" component={CheckoutSuccessPage} />
          
          {/* Admin Routes */}
          <Route path="/admin" component={AdminLoginPage} />
          <ProtectedRoute path="/admin/dashboard" component={AdminDashboardPage} adminRequired={true} />
          <ProtectedRoute path="/admin/products" component={AdminProductsPage} adminRequired={true} />
          <ProtectedRoute path="/admin/settings" component={AdminSettingsPage} adminRequired={true} />
          
          {/* Client Routes */}
          <ProtectedRoute path="/client/dashboard" component={ClientDashboardPage} />
          <ProtectedRoute path="/client/purchases" component={ClientPurchasesPage} />
          
          {/* Fallback to 404 */}
          <Route component={NotFound} />
        </Switch>
      </main>
      <Footer />
      <CartSidebar />
    </div>
  );
}

export default App;
