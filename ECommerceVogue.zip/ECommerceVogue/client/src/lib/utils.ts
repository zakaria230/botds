import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatPrice(price: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(price / 100);
}

export function getImageFallback(title: string): string {
  return `https://ui-avatars.com/api/?name=${encodeURIComponent(title)}&background=3B82F6&color=fff`;
}

export const INITIAL_PRODUCTS = [
  {
    id: 1,
    title: "Urban Streetwear Collection",
    description: "6 designs | AI, PSD, PNG formats",
    price: 4999, // $49.99
    imageUrl: "https://images.unsplash.com/photo-1551232864-3f0890e580d9?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
    fileUrl: "/files/urban-streetwear-collection.zip",
    fileFormats: ["AI", "PSD", "PNG"],
    category: "Streetwear",
    featured: true,
    label: "TRENDING",
    createdAt: new Date().toISOString(),
  },
  {
    id: 2,
    title: "Minimalist Tee Templates",
    description: "8 designs | AI, PSD, PNG formats",
    price: 3999, // $39.99
    imageUrl: "https://images.unsplash.com/photo-1554568218-0f1715e72254?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
    fileUrl: "/files/minimalist-tee-templates.zip",
    fileFormats: ["AI", "PSD", "PNG"],
    category: "T-shirts",
    featured: true,
    label: "NEW",
    createdAt: new Date().toISOString(),
  },
  {
    id: 3,
    title: "Premium Hoodie Bundle",
    description: "4 designs | AI, PSD, PNG formats",
    price: 5999, // $59.99
    imageUrl: "https://images.unsplash.com/photo-1525507119028-ed4c629a60a3?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
    fileUrl: "/files/premium-hoodie-bundle.zip",
    fileFormats: ["AI", "PSD", "PNG"],
    category: "Hoodies",
    featured: true,
    label: "",
    createdAt: new Date().toISOString(),
  },
  {
    id: 4,
    title: "Vintage Graphic Collection",
    description: "12 designs | AI, PSD, PNG formats",
    price: 6999, // $69.99
    imageUrl: "https://images.unsplash.com/photo-1571945153237-4929e783af4a?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
    fileUrl: "/files/vintage-graphic-collection.zip",
    fileFormats: ["AI", "PSD", "PNG"],
    category: "T-shirts",
    featured: true,
    label: "BESTSELLER",
    createdAt: new Date().toISOString(),
  },
  {
    id: 5,
    title: "Athleisure Design Pack",
    description: "5 designs | AI, PSD, PNG formats",
    price: 4499, // $44.99
    imageUrl: "https://images.unsplash.com/photo-1576566588028-4147f3842f27?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
    fileUrl: "/files/athleisure-design-pack.zip",
    fileFormats: ["AI", "PSD", "PNG"],
    category: "Streetwear",
    featured: true,
    label: "",
    createdAt: new Date().toISOString(),
  },
  {
    id: 6,
    title: "Sustainable Fashion Templates",
    description: "7 designs | AI, PSD, PNG formats",
    price: 5499, // $54.99
    imageUrl: "https://images.unsplash.com/photo-1595341888016-a392ef81b7de?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
    fileUrl: "/files/sustainable-fashion-templates.zip",
    fileFormats: ["AI", "PSD", "PNG"],
    category: "Jackets",
    featured: true,
    label: "NEW",
    createdAt: new Date().toISOString(),
  },
];

export const PRODUCT_CATEGORIES = [
  "All Designs",
  "T-shirts",
  "Streetwear",
  "Hoodies",
  "Jackets",
];

export const TESTIMONIALS = [
  {
    id: 1,
    text: "The design templates from DesignKorv saved me countless hours. High-quality files, easy to customize, and the support is amazing.",
    name: "Sarah Johnson",
    title: "Fashion Designer @ ModStyle",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80",
  },
  {
    id: 2,
    text: "As a small clothing brand, finding professional designs at an affordable price was a game-changer. Top quality and incredible value.",
    name: "Michael Chen",
    title: "Founder @ UrbanThread",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80",
  },
  {
    id: 3,
    text: "The level of detail in these templates is outstanding. They've helped us launch our seasonal collections much faster than before.",
    name: "Emma Rodriguez",
    title: "Designer @ FashionFwd",
    avatar: "https://images.unsplash.com/photo-1534751516642-a1af1ef26a56?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80",
  },
];
